window.onload = () => {
  $(".slick").slick({
    slidesToShow: 4,
    slidesToScroll: 1,
  });
  $(".slick-3").slick({
    // responsive: [
    //   {
    //     breakpoint: 1366,
    //     settings: "unslick",
    //   },
    // ],
    slidesToShow: 3,
    slidesToScroll: 1,
  });
};
